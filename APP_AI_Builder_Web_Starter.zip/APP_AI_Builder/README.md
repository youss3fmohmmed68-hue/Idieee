# APP — AI App Builder

A bilingual (Arabic/English) web-first AI app builder starter.

## Included
- Responsive React + TypeScript + Vite frontend.
- Arabic/English language switch with RTL/LTR support.
- Chat-style app creation interface.
- Demo project generation for prompts such as an online store.
- Live preview panel with generated demo screens.
- Node.js/Express backend with a demo structured app-spec endpoint.

## Important
This is a working starter UI with a **demo generation engine**. It does not yet connect to a real AI model, persist projects, publish apps, or build APK files. Those require provider credentials and additional backend/build infrastructure.

## Run locally or in a cloud IDE
Requirements: Node.js 20+

```bash
npm install
npm run dev
```

Frontend: `http://localhost:5173`

Run the backend in another terminal:
```bash
cd server
npm install
npm run dev
```
Backend: `http://localhost:8787`

Set `VITE_API_URL` in `.env` if your backend runs elsewhere:
```env
VITE_API_URL=http://localhost:8787
```

## Suggested next milestones
1. Connect a real AI provider from the server only. Never expose API keys in frontend code.
2. Validate model output against a strict app-spec schema.
3. Add authentication and project persistence (e.g. Supabase).
4. Add a component editor and version history.
5. Add secure web publishing.
6. Add isolated cloud Android build workers for APK/AAB export.

Generated code must be treated as untrusted. Prefer declarative app specifications and allowlisted components over executing arbitrary model-generated code.
