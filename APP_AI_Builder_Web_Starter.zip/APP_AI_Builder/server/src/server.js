import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import { randomUUID } from 'node:crypto'

const app = express()
app.use(helmet())
app.use(cors({ origin: true }))
app.use(express.json({ limit: '24kb' }))

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'app-ai-builder', version: '0.1.0' })
})

app.post('/api/generate', (req, res) => {
  const prompt = typeof req.body?.prompt === 'string' ? req.body.prompt.trim() : ''
  if (prompt.length < 5) return res.status(400).json({ error: 'Please describe your app in at least 5 characters.' })
  if (prompt.length > 5000) return res.status(413).json({ error: 'Prompt is too long.' })

  const store = /متجر|تسوق|منتجات|store|shop|ecommerce/i.test(prompt)
  const spec = store ? {
    name: 'متجري',
    description: 'مخطط متجر إلكتروني تجريبي.',
    screens: [
      { id: 'home', title: 'الرئيسية', components: [{ type: 'hero', label: 'اكتشف منتجاتنا' }, { type: 'grid', label: 'منتجات مميزة' }] },
      { id: 'products', title: 'المنتجات', components: [{ type: 'search', label: 'ابحث عن منتج' }, { type: 'grid', label: 'كل المنتجات' }] },
      { id: 'cart', title: 'السلة', components: [{ type: 'cart', label: 'سلة المشتريات' }] },
      { id: 'account', title: 'حسابي', components: [{ type: 'form', label: 'تسجيل الدخول' }] }
    ],
    products: [
      { name: 'سماعة لاسلكية', price: '850 جنيه', emoji: '🎧' },
      { name: 'ساعة ذكية', price: '1,250 جنيه', emoji: '⌚' },
      { name: 'حقيبة يومية', price: '620 جنيه', emoji: '🎒' },
      { name: 'كاميرا صغيرة', price: '1,900 جنيه', emoji: '📷' }
    ]
  } : {
    name: 'تطبيقي الجديد',
    description: `مخطط أولي مبني على فكرتك: ${prompt}`,
    screens: [
      { id: 'home', title: 'الرئيسية', components: [{ type: 'hero', label: 'مرحباً بك' }] },
      { id: 'account', title: 'حسابي', components: [{ type: 'form', label: 'تسجيل الدخول' }] }
    ]
  }

  res.json({
    ok: true,
    mode: 'demo',
    notice: 'Demo specification only. Connect an AI provider for real generation.',
    project: { id: randomUUID(), spec }
  })
})

const port = Number(process.env.PORT || 8787)
app.listen(port, '0.0.0.0', () => console.log(`APP server listening on ${port}`))
