import type { AppSpec } from './types'

export function makeDemoSpec(prompt: string): AppSpec {
  const isStore = /متجر|تسوق|منتجات|store|shop|ecommerce/i.test(prompt)
  if (isStore) {
    return {
      name: 'متجري',
      description: 'متجر إلكتروني تجريبي تم إنشاؤه من وصفك.',
      screens: [
        { id: 'home', title: 'الرئيسية', components: [{ type: 'hero', label: 'اكتشف منتجاتنا' }, { type: 'grid', label: 'المنتجات المميزة' }] },
        { id: 'products', title: 'المنتجات', components: [{ type: 'search', label: 'ابحث عن منتج' }, { type: 'grid', label: 'كل المنتجات' }] },
        { id: 'cart', title: 'السلة', components: [{ type: 'cart', label: 'سلة المشتريات' }] },
        { id: 'account', title: 'حسابي', components: [{ type: 'form', label: 'تسجيل الدخول' }] }
      ],
      products: [
        { name: 'سماعة لاسلكية', price: '850 جنيه', emoji: '🎧' },
        { name: 'ساعة ذكية', price: '1,250 جنيه', emoji: '⌚' },
        { name: 'حقيبة يومية', price: '620 جنيه', emoji: '🎒' },
        { name: 'كاميرا صغيرة', price: '1,900 جنيه', emoji: '📷' }
      ]
    }
  }
  return {
    name: 'تطبيقي الجديد',
    description: `مخطط أولي مبني على فكرتك: ${prompt}`,
    screens: [
      { id: 'home', title: 'الرئيسية', components: [{ type: 'hero', label: 'مرحباً بك' }, { type: 'button', label: 'ابدأ الآن' }] },
      { id: 'about', title: 'عن التطبيق', components: [{ type: 'text', label: 'معلومات التطبيق' }] },
      { id: 'account', title: 'حسابي', components: [{ type: 'form', label: 'تسجيل الدخول' }] }
    ]
  }
}
