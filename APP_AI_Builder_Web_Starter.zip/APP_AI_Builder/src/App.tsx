import { useMemo, useState } from 'react'
import {
  ArrowUp, Bot, ChevronDown, Code2, Eye, Folder, Globe2, Layers3,
  Menu, MessageSquare, MoreHorizontal, Plus, Smartphone, Sparkles,
  WandSparkles, X
} from 'lucide-react'
import { makeDemoSpec } from './demo'
import type { AppSpec, Message } from './types'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8787'

export default function App() {
  const [lang, setLang] = useState<'ar' | 'en'>('ar')
  const [prompt, setPrompt] = useState('')
  const [busy, setBusy] = useState(false)
  const [spec, setSpec] = useState<AppSpec | null>(null)
  const [activeScreen, setActiveScreen] = useState('home')
  const [showPreview, setShowPreview] = useState(true)
  const [mobileMenu, setMobileMenu] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    { id: 'welcome', role: 'assistant', content: 'أهلاً بيك في APP! احكيلي فكرة التطبيق اللي نفسك تعمله، وأنا هساعدك تحوّلها لمشروع.' }
  ])

  const ar = lang === 'ar'
  const direction = ar ? 'rtl' : 'ltr'
  const currentScreen = useMemo(
    () => spec?.screens.find(s => s.id === activeScreen) || spec?.screens[0],
    [spec, activeScreen]
  )

  async function sendMessage(value = prompt) {
    const text = value.trim()
    if (!text || busy) return
    setPrompt('')
    setMessages(prev => [...prev, { id: crypto.randomUUID(), role: 'user', content: text }])
    setBusy(true)
    try {
      let nextSpec: AppSpec
      try {
        const response = await fetch(`${API_URL}/api/generate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt: text, language: lang })
        })
        if (!response.ok) throw new Error('API unavailable')
        const data = await response.json()
        nextSpec = data.project?.spec || makeDemoSpec(text)
      } catch {
        nextSpec = makeDemoSpec(text)
      }
      setSpec(nextSpec)
      setActiveScreen(nextSpec.screens[0]?.id || 'home')
      setMessages(prev => [...prev, {
        id: crypto.randomUUID(),
        role: 'assistant',
        content: ar
          ? `جهزت لك مخطط أولي لتطبيق «${nextSpec.name}»! تقدر تشوف المعاينة على اليمين، وبعدها اطلب مني أي تعديل.`
          : `I created an initial specification for "${nextSpec.name}". Check the preview and tell me what to change.`
      }])
    } finally {
      setBusy(false)
    }
  }

  const suggestions = ar
    ? ['اصنع لي متجر إلكتروني', 'اعمل تطبيق لإدارة المهام', 'أنشئ تطبيق حجوزات']
    : ['Build an online store', 'Create a task manager', 'Build a booking app']

  return (
    <div className="app-shell" dir={direction}>
      <header className="topbar">
        <button className="icon-btn mobile-only" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Menu">
          {mobileMenu ? <X size={19}/> : <Menu size={19}/>}
        </button>
        <a className="brand" href="#"><span className="brand-mark"><Sparkles size={19}/></span><span>APP</span></a>
        <div className="top-center"><span className="status-dot"/> {ar ? 'مساحة عمل جديدة' : 'New workspace'} <ChevronDown size={14}/></div>
        <div className="top-actions">
          <button className="lang-btn" onClick={() => setLang(ar ? 'en' : 'ar')}><Globe2 size={15}/>{ar ? 'English' : 'العربية'}</button>
          <button className="share-btn" onClick={() => alert(ar ? 'ميزة المشاركة ستضاف لاحقاً.' : 'Sharing will be added later.')}>{ar ? 'مشاركة' : 'Share'}</button>
          <div className="avatar">A</div>
        </div>
      </header>

      <div className="workspace">
        <aside className={`sidebar ${mobileMenu ? 'sidebar-open' : ''}`}>
          <button className="new-project" onClick={() => { setSpec(null); setMessages([{id: crypto.randomUUID(), role:'assistant', content: ar ? 'مشروع جديد! اكتب فكرة التطبيق.' : 'New project! Describe your app idea.'}]); setMobileMenu(false) }}>
            <Plus size={17}/> {ar ? 'مشروع جديد' : 'New project'}
          </button>
          <div className="side-label">{ar ? 'مساحة العمل' : 'WORKSPACE'}</div>
          <button className="side-link active"><MessageSquare size={17}/>{ar ? 'منشئ التطبيقات' : 'App builder'}</button>
          <button className="side-link"><Folder size={17}/>{ar ? 'مشاريعي' : 'My projects'} <span className="side-count">{spec ? 1 : 0}</span></button>
          <button className="side-link"><Layers3 size={17}/>{ar ? 'القوالب' : 'Templates'}</button>
          <div className="sidebar-bottom">
            <div className="upgrade-card">
              <Sparkles size={17}/>
              <strong>{ar ? 'أطلق أفكارك' : 'Bring ideas to life'}</strong>
              <p>{ar ? 'أنشئ وعدّل تطبيقاتك من مكان واحد.' : 'Create and refine apps in one place.'}</p>
              <span>{ar ? 'نسخة تجريبية' : 'Starter preview'}</span>
            </div>
            <button className="side-link"><Bot size={17}/>{ar ? 'المساعدة' : 'Help'}</button>
          </div>
        </aside>

        <main className="chat-area">
          <div className="chat-heading">
            <div><div className="eyebrow"><WandSparkles size={14}/> {ar ? 'مساعد بناء التطبيقات' : 'AI APP BUILDER'}</div>
              <h1>{ar ? 'إيه التطبيق اللي في بالك؟' : 'What do you want to build?'}</h1>
              <p>{ar ? 'اكتب فكرتك ببساطة، وابدأ بناء تطبيقك مع APP.' : 'Describe your idea and start building with APP.'}</p>
            </div>
            <button className="preview-toggle" onClick={() => setShowPreview(!showPreview)}><Eye size={16}/>{ar ? 'المعاينة' : 'Preview'}</button>
          </div>

          <div className="conversation">
            {messages.map(m => <div className={`message-row ${m.role}`} key={m.id}>
              <div className="message-avatar">{m.role === 'assistant' ? <Sparkles size={16}/> : 'أ'}</div>
              <div className="message-bubble">{m.content}</div>
            </div>)}
            {busy && <div className="message-row assistant"><div className="message-avatar"><Bot size={16}/></div><div className="typing"><i/><i/><i/></div></div>}
          </div>

          <div className="composer-wrap">
            {!spec && <div className="suggestions">{suggestions.map(s => <button key={s} onClick={() => sendMessage(s)}>{s}</button>)}</div>}
            <div className="composer">
              <textarea value={prompt} onChange={e => setPrompt(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage() } }} placeholder={ar ? 'صف التطبيق اللي عايز تنشئه...' : 'Describe the app you want to create...'} rows={2}/>
              <div className="composer-footer"><span><Sparkles size={13}/>{ar ? 'APP AI' : 'APP AI'} · {ar ? 'اكتب وصفاً واضحاً' : 'Be specific'}</span><button className="send-btn" onClick={() => sendMessage()} disabled={busy || !prompt.trim()}><ArrowUp size={19}/></button></div>
            </div>
            <p className="disclaimer">{ar ? 'APP في نسخته التجريبية ينشئ مخططاً ومعاينة توضيحية، وليس تطبيقاً منشوراً بعد.' : 'APP demo currently creates a specification and illustrative preview, not a deployed app.'}</p>
          </div>
        </main>

        {showPreview && <section className="preview-area">
          <div className="preview-header"><div><Eye size={16}/><strong>{ar ? 'معاينة التطبيق' : 'App preview'}</strong></div><button className="icon-btn"><MoreHorizontal size={19}/></button></div>
          {spec ? <div className="preview-content">
            <div className="device-label"><Smartphone size={14}/>{ar ? 'معاينة الهاتف' : 'Mobile preview'}<span className="live-pill">{ar ? 'تجريبي' : 'DEMO'}</span></div>
            <div className="phone-frame" dir="rtl">
              <div className="phone-notch"/>
              <div className="store-top"><span className="store-logo">{spec.name}</span><span>♡　⌕</span></div>
              <div className="store-hero"><small>{ar ? 'مرحباً بك' : 'WELCOME'}</small><h2>{currentScreen?.title || spec.name}</h2><p>{spec.description}</p><button>{ar ? 'اكتشف الآن' : 'Explore'}</button></div>
              <div className="phone-section-title">{ar ? 'اكتشف المنتجات' : 'Explore products'}</div>
              <div className="product-grid">
                {(spec.products || [{name:'عنصر مميز',price:'—',emoji:'✨'},{name:'خدمة جديدة',price:'—',emoji:'🚀'}]).map(p => <div className="product-card" key={p.name}><div className="product-art">{p.emoji}</div><b>{p.name}</b><span>{p.price}</span></div>)}
              </div>
              <div className="phone-nav"><span>⌂</span><span>♡</span><span>🛒</span><span>☻</span></div>
            </div>
            <div className="screen-tabs">{spec.screens.map(s => <button key={s.id} className={activeScreen === s.id ? 'selected' : ''} onClick={() => setActiveScreen(s.id)}>{s.title}</button>)}</div>
            <div className="spec-summary"><strong>{spec.name}</strong><span>{spec.screens.length} {ar ? 'صفحات' : 'screens'}</span></div>
          </div> : <div className="empty-preview"><div className="empty-icon"><Smartphone size={28}/></div><strong>{ar ? 'معاينتك هتظهر هنا' : 'Your preview appears here'}</strong><p>{ar ? 'اكتب فكرة التطبيق في المحادثة عشان نبدأ إنشاء أول مشروع.' : 'Describe an app in chat to create your first project.'}</p><div className="empty-lines"><i/><i/><i/></div></div>}
          <div className="preview-footer"><Code2 size={14}/>{ar ? 'مخطط واجهة تجريبي' : 'Demo UI specification'}<span>v0.1</span></div>
        </section>}
      </div>
    </div>
  )
}
