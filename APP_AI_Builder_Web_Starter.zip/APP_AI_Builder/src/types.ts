export type Message = {
  id: string
  role: 'assistant' | 'user'
  content: string
}

export type AppSpec = {
  name: string
  description: string
  screens: { id: string; title: string; components: { type: string; label: string }[] }[]
  products?: { name: string; price: string; emoji: string }[]
}
